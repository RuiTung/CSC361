#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <net/if.h>
#include <netinet/if_ether.h>
#include <pcap.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/time.h>
#include <time.h>
#include <arpa/inet.h>

#define MAX_NUM_CONNECTION 2000
#define MAX_PACK_PER_CONNECTION 4000
#define MAX_STR_LEN 50


int total_packets = 0;
int total_connection = 0; 
double standard_time = 0;
int completeTCP = 0;
int resetTCP = 0;
int withoutFin = 0;
int total_num_comp_packts = 0;

struct connection {
	char ip_src[MAX_STR_LEN]; /*source ip*/
	char ip_dst[MAX_STR_LEN]; /*destination ip*/
	uint16_t port_src; /*source port number*/
	uint16_t port_dst; /*destination port number*/
	/*flag count*/
	int syn_count;
	int fin_count;
	int rst_count;

	double starting_time;
	double ending_time;
	double duration;
	int num_packet_src; /*number of packets sent out by source*/
	int num_packet_dst; /*number of packets sent out by destination*/
	int num_total_packets;
	int cur_data_len_src; /*num data bytes*/
	int cur_data_len_dst; /*num data bytes*/
	int cur_total_data_len;
	uint16_t max_win_size; /*max window size*/
	uint16_t min_win_size; /*min window size*/
	double sum_win_size;
	//struct round_trip rtt_ary_src[MAX_NUM_CONNECTION/4]; /*assume 1000*/
	int rtt_ary_src_len; /*the size of the rtt_ary_src array*/
	//struct round_trip rtt_ary_dst[MAX_NUM_CONNECTION/4]; /*assume 1000*/
	//int rtt_ary_dst_len; /*the size of the rtt_ary_dst array*/
	int is_set;

	int isComplete;
};
struct connection con[MAX_PACK_PER_CONNECTION];

struct TCP_hdr {
	u_short th_sport;
	u_short th_dport;
	//u_short th_len;
	unsigned int th_seq;
	unsigned int th_ack;
	u_char th_offx2;
	#define TH_OFF(th) (((th) -> th_offx2 & 0xf0) >> 4)
	u_char th_flags;
	u_short th_win;
	u_short th_sum;
	u_short th_urp;
};


struct packet {
	u_short src_port;
	u_short dst_port;
	char src_ip[MAX_STR_LEN]; /*source ip*/
	char dst_ip[MAX_STR_LEN]; /*destination ip*/
	//u_short th_len;
	unsigned int seq_num;
	unsigned int ack_num;
	u_char th_offx2;
	#define TH_OFF(th) (((th) -> th_offx2 & 0xf0) >> 4)
	u_char flag;
	u_short window;
	u_short th_sum;
	u_short th_urp;
	int used;
	int data_bytes;
	double times;
};

struct packet items[MAX_PACK_PER_CONNECTION];

int parse_packet(const unsigned char *packet, struct timeval ts, unsigned int capture_len) {
	struct ip *ip;
	struct TCP_hdr *tcp;
	struct in_addr s_ip;
	struct in_addr d_ip;
	unsigned int IP_header_length;
	unsigned int captured = capture_len;

	if(capture_len < sizeof(struct ether_header)) {
		printf("Error: Invalid Ethernet header length.\n");
		//return 0;
		//perror("Error: ");
		return 0;
	}

	packet += sizeof(struct ether_header);
	capture_len -= sizeof(struct ether_header);
	ip = (struct ip*) packet;
	IP_header_length = ip -> ip_hl * 4;


	if(capture_len < sizeof(struct ip)) {
		printf("IP header.");
		return 0;
	}

	if(capture_len < IP_header_length) {
		printf("Error: Invalid IP header length\n");
		//return 0;
		//perror("Error: ");
		return 0;
	}

	if(ip -> ip_p != IPPROTO_TCP) {
		printf("Error: non-TCP packet\n");
		//return 0;
		//perror("Error: ");
		return 0;
	}

	packet += IP_header_length;
	capture_len -= IP_header_length;

	if(capture_len < sizeof(struct TCP_hdr)) {
		printf("Error: Invalid TCP header length\n");
		//return 0;
		//perror("Error: ");
		return 0;
	}

	tcp = (struct TCP_hdr*) packet;
	int size_tcp = TH_OFF(tcp) * 4;
	capture_len =  TH_OFF(tcp) * 4;
	int data = captured - sizeof(struct ether_header) - IP_header_length - size_tcp;
	s_ip = ip -> ip_src;
	d_ip = ip -> ip_dst;
	packet += IP_header_length;
	capture_len -= IP_header_length;
	
	static char timestamp_string_buf[256];
	sprintf(timestamp_string_buf, "%d.%06d", (int) ts.tv_sec, (int) ts.tv_usec);
	double t = atof(timestamp_string_buf);
	if(!standard_time) {
		standard_time = t;
	}

	char *addr = inet_ntoa(ip->ip_src);
    strcpy(items[total_packets].src_ip, addr);
    int size = strlen(items[total_packets].src_ip);
    items[total_packets].src_ip[size] = '\0';
    addr = inet_ntoa(ip->ip_dst);
    strcpy(items[total_packets].dst_ip, addr);
    size = strlen(items[total_packets].dst_ip);
    items[total_packets].dst_ip[size] = '\0';

    items[total_packets].src_port = ntohs(tcp->th_sport);
    items[total_packets].dst_port = ntohs(tcp->th_dport);
    items[total_packets].seq_num = ntohl(tcp->th_seq);
    items[total_packets].ack_num = ntohl(tcp->th_ack);
    items[total_packets].flag = (unsigned int)tcp->th_flags;
    items[total_packets].window = ntohs(tcp->th_win);
    items[total_packets].used = 0;
    items[total_packets].data_bytes = data;
    items[total_packets].times = t;

    total_packets++;
    return 0;
}

void printRest(int i);

void check_connection() {
	int i;
	int first_time_flag = 1;
	int j;
	int total_packets_num;
	con[0].sum_win_size = 0;
    for(i = 0; i < total_packets; i++) {
    	if(items[i].used == 0) {

    		strcpy(con[total_connection].ip_src, items[i].src_ip);
		    strcpy(con[total_connection].ip_dst, items[i].dst_ip);
		    con[total_connection].port_src = items[i].src_port;
		    con[total_connection].port_dst = items[i].dst_port;
		    con[total_connection].starting_time = items[i].times;
    		
	    	for(j = i; j < total_packets; j++) {
		    	if((items[i].src_port == items[j].src_port && items[i].dst_port == items[j].dst_port && !strcmp(items[i].dst_ip, items[j].dst_ip) && !strcmp(items[i].src_ip, items[j].src_ip) && items[j].used == 0) || (items[i].dst_port == items[j].src_port && items[i].src_port == items[j].dst_port && !strcmp(items[i].src_ip, items[j].dst_ip) && !strcmp(items[i].dst_ip, items[j].src_ip) && items[j].used == 0)) {
		    			
		    		items[j].used = 1;
		        	
					if(items[j].flag == 2 || items[j].flag == 18 ) {
						con[total_connection].syn_count++;

					} else if(items[j].flag == 4 || items[j].flag == 20) {
						con[total_connection].rst_count++;
					} else if(items[j].flag == 1 || items[j].flag == 17) {
						con[total_connection].fin_count++;
					}

					con[total_connection].ending_time = items[j].times;

					if(items[i].src_port == items[j].src_port ) {
		    			con[total_connection].num_packet_src++;
		    			con[total_connection].cur_data_len_src += items[j].data_bytes;
		    			con[total_connection].cur_total_data_len += items[j].data_bytes;
		    			

					} else if(items[i].src_port == items[j].dst_port) {
		    			con[total_connection].num_packet_dst++;
		    			con[total_connection].cur_data_len_dst += items[j].data_bytes;
		    			con[total_connection].cur_total_data_len += items[j].data_bytes;
		    			
		    		}
		    		if(first_time_flag == 1){
		    			con[total_connection].min_win_size = items[j].window;
		    			con[total_connection].max_win_size = items[j].window;
		    			first_time_flag = 0;
		    		}else{
		    			con[total_connection].min_win_size = (con[total_connection].min_win_size>items[j].window) ? (items[j].window):(con[total_connection].min_win_size);
		    			con[total_connection].max_win_size = (con[total_connection].max_win_size<items[j].window) ? (items[j].window):(con[total_connection].max_win_size);		
		    		}
		    		con[total_connection].sum_win_size += items[j].window;
		    		total_num_comp_packts = total_num_comp_packts+con[total_connection].num_packet_src+con[total_connection].num_packet_dst;
		    	}
		    }
		    total_connection++;
		    first_time_flag = 1;
		    con[total_connection].sum_win_size = 0;   
		}
	}
}


void print() {
	printf("A) Total number of connections: %d\n", total_connection);
	printf("--------------------------------------------------\n");

	printf("B) Connections' details: \n\n");

	int i;
	for(i = 1; i <= total_connection; i++) {

		printf("Connection %d\n", i);
		printf("Source Address: %s\n", con[i - 1].ip_src);
		printf("Destination address: %s\n", con[i - 1].ip_dst);  
		printf("Source Port: %d\n", con[i - 1].port_src);
		printf("Destination Port: %d\n", con[i - 1].port_dst);

		printf("Status: S%dF%d\n", con[i - 1].syn_count, con[i - 1].fin_count);
		if(con[i - 1].rst_count != 0) {
			resetTCP++;
		}
		if(con[i - 1].syn_count == 1 && con[i - 1].fin_count == 1) {
			con[i - 1].isComplete = 1;
			completeTCP++;
			printRest(i);
		} else if(con[i - 1].syn_count == 2 && con[i - 1].fin_count == 1) {
			con[i - 1].isComplete = 1;
			completeTCP++;
			printRest(i);
		} else if(con[i - 1].syn_count == 2 && con[i - 1].fin_count == 2) {
			con[i - 1].isComplete = 1;
			completeTCP++;
			printRest(i);
		}
		if(con[i - 1].fin_count == 0) {
			withoutFin++;
		}
		
		printf("END\n\n");
		if(i != total_connection) {
			printf("++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n");
		}
		

	}
	printf("------------------------------------------------------\n");
	printf("C) General\n");
	printf("Total number of complete TCP connections: %d\n", completeTCP);
	printf("Total number of reset TCP connections: %d\n", resetTCP);
	printf("Number of TCP connections that were still open when the trace capture ended: %d\n", withoutFin);
	printf("----------------------------------------------------\n");

	int j;
	double min;
	double max;
	double sum = 0;
	double sumW = 0;
	int minP;
	int maxP;
	int sumP;
	int minW = 0;
	int maxW = 0;
	int flags = 1;
	for(j = 1; j <= total_connection; j++) {
		if(con[j - 1].isComplete == 1) {
			sum += con[j - 1].duration;
			sumP += con[j - 1].num_total_packets;
			sumW += con[j - 1].sum_win_size;
			if(flags == 1) {
				min = con[j - 1].duration;
				max = con[j - 1].duration;
				

				minP = con[j - 1].num_total_packets;
				maxP = con[j - 1].num_total_packets;


				minW = con[j - 1].min_win_size;
				maxW = con[j - 1].max_win_size;

				flags = 0;

			}
			if(max < con[j - 1].duration) {
				max = con[j - 1].duration;
			}
			if(min > con[j - 1].duration) {
				min = con[j - 1].duration;
			}

			if(maxP < con[j - 1].num_total_packets) {
				maxP = con[j - 1].num_total_packets;
			}
			if(minP > con[j - 1].num_total_packets) {
				minP = con[j - 1].num_total_packets;
			}


			if(maxW < con[j - 1].max_win_size) {
				maxW = con[j - 1].max_win_size;
			}
			if(minW > con[j - 1].min_win_size) {
				minW = con[j - 1].min_win_size;
			}


		}


	}
	printf("\nD) Complete TCP connections:\n\n");
	printf("Minimum time duration: %.3f\n", min); 
	printf("Mean time duration: %.3f\n", sum / completeTCP); 
	printf("Maximum time duration: %.3f\n", max); 

	printf("\nMinimum number of packets including both send/received: %d\n", minP);
	printf("Mean number of packets including both send/received: %d\n", sumP / completeTCP);
	printf("Maximum number of packets including both send/received: %d\n", maxP);

	printf("\nMinimum number of packets including both send/received:\n");
	printf("Mean number of packets including both send/received:\n");
	printf("Maximum number of packets including both send/received:\n");

	printf("\nMinimum receive window sizes including both send/received: %d\n", minW);
	printf("Mean receive window sizes including both send/received: %d\n", (int)(sumW / total_num_comp_packts));
	printf("Maximum receive window sizes including both send/received:%d\n", maxW);




}

void printRest(int i) {

		double start = con[i - 1].starting_time - standard_time;
		double end = con[i - 1].ending_time - standard_time;
		con[i - 1].duration = end - start;
		printf("Start time: %.3f\n", start);
		printf("End time: %.3f\n", end);
		printf("Duration: %.3f\n", con[i - 1].duration);
		printf("Number of packets sent from Source to Destination: %d\n", con[i - 1].num_packet_src);
		printf("Number of packets sent from Destination to Source: %d\n", con[i - 1].num_packet_dst);
		con[i - 1].num_total_packets = con[i - 1].num_packet_src + con[i - 1].num_packet_dst;
		printf("Total number of packets: %d\n", con[i - 1].num_total_packets);
		int totalDataBytes = con[i - 1].cur_data_len_src + con[i - 1].cur_data_len_dst;
		printf("Number of data bytes sent from Source to Destination: %d\n", con[i - 1].cur_data_len_src);
		printf("Number of data bytes sent from Destination to Source: %d\n", con[i - 1].cur_data_len_dst);
		printf("Total number of data bytes: %d\n", totalDataBytes);


}



int main(int argc, char *argv[]) {
	//int parse_val;

	if(argc != 2) {
		printf("Error: Program requires one argument, the trace file\n");
		exit(1);
	}
	pcap_t *pcap;
	struct pcap_pkthdr header;
	char errbuf[PCAP_ERRBUF_SIZE];
	const unsigned char *packet;
	pcap = pcap_open_offline(argv[1], errbuf);

	if(pcap == NULL) {
		printf("Couldn't open pcap file %s\n", errbuf);
		exit(1);
	}

	// check whether there exists packet and pick the detailed information
	while((packet = pcap_next(pcap, &header)) != NULL) {

		//parse_val = parse_packet(packet, header.ts, header.caplen);
		parse_packet(packet, header.ts, header.caplen);
		

	}
	check_connection();

	//printf("total_packets = %d\n", total_packets);

	print();
	
	return 0;
}
