
Rui Ma
CSC361 Project#2 - TCP Traffic Analysis

--------------------------- Function of files ---------------------------
assign2.c:	Combination of methods to process the trace file and computes TCP information 			about TCP connections
Makefile: Compile assign2.c
Readme.txt: Information of how to use files for assign2.c
sample-capture-file: traffic file

--------------------------- How to run code ---------------------------

First step:		run make (assign2.c)

Second step:	run ./assign2 <traffic file name>
			e.g. ./assign2 sample-capture-file

							




