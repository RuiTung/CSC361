								HTTP Server-Client Architecture

Description
A simple web cient and a simple web server. Go to the SimpServer/SimpClient directory and type "make" to run make file.


CLIENT-SIDE
The client uses 3 functions except main(): parse_URI, open_connection, perform_HTTP

Parse_URI():
The client will parse user's input of http address (including hostname, port number and the file path) in the terminal into three part: "host", "port number" and "path"

Open_Connection():
If a character string is detected as the hostname, it will convert it into an IP, then uses connect() to establish connection with the host, with the given port number

Perform_HTTP():
It sends a request to the connected server in the form of "GET protocol/hostname/path HTTP/1.0". If response can be received, it will split the response into header and body parts.



SERVER-SIDE
The server uses a main loop, and a function of perform_HTTP() for handling incoming requests

perform_HTTP():
It opens a socket for the new connection, and checks the path for the file, and if it can be found, a "200 OK message" will send back, and with the content of the web. However if file is not found, a "404 Not Found message" will send back; and if the request can not be recognized, a "501 Implemented message" will send back.



Building and Running
Type "make" in terminal to compile the program.
Type "make clear" in terminal to clean the compile file.

Client-side
Type in based on the following format: ./SimpClient host:portnumber/path.file
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
For example: 
/SimpClient http://www.uvic.ca/index.html

---Request begin---
GET http://www.uvic.ca/index.html HTTP/1.0
Host: www.uvic.ca
Connection: Keep-Alive

---Request end---
HTTP request sent, awaiting response...

---Response header ---
HTTP/1.1 301 Moved Permanently
Date: Sat, 28 May 2016 04:27:01 GMT
Server: Apache/2.2.31 (Unix) mod_jk/1.2.40
Location: http://www.uvic.ca/
Content-Length: 227
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: text/html; charset=iso-8859-1
Set-Cookie: www_www=2481416334.20480.0000; path=/

--- Response body ---

<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>301 Moved Permanently</title>
</head><body>
<h1>Moved Permanently</h1>
<p>The document has moved <a href="http://www.uvic.ca/">here</a>.</p>
</body></html>
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _


Server-side
Type in based on the following format: ./SimpServer portnumber path/
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
For example:
./SimpServer 8000 web/
_ _ _ _ _ _ _ _ _ _ _ _
Then in the client side, type in based on the following format: /SimpClient host:portnumber/path.file
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
For example:
./SimpClient http://142.104.74.70:8000/index.html

---Request begin---
GET http://142.104.74.70:8000/index.html HTTP/1.0
Host: 142.104.74.70
Connection: Keep-Alive

---Request end---
HTTP request sent, awaiting response...

---Response header ---
HTTP/1.0 200 OK.
Date: Fri May 27 21:32:52 2016 GMT
Server: 142.104.74.70

--- Response body ---

 <!DOCTYPE html>
<html>
<body>

<h1>My First Heading</h1>

<p>My first paragraph.</p>

</body>
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _


