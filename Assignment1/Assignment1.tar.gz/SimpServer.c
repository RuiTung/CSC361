/*------------------------------
* server.c
* Description: HTTP server program
* CSC 361
* Instructor: Kui Wu
-------------------------------*/
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define MAX_STR_LEN 9898         /* maximum string length */
#define SERVER_PORT_ID 9898     /* server port number */
void cleanExit();
/*---------------------main() routine--------------------------*
 * tasks for main
 * generate socket and get socket id,
 * max number of connection is 3 (maximum length the queue of pending connections may grow to)
 * Accept request from client and generate new socket
 * Communicate with client and close new socket after done
 *---------------------------------------------------------------------------*/

main(int argc, char *argv[]) {
    int newsockid; /* return value of the accept() call */
	int listenfd; //file descriptor
	int port = atoi(argv[1]);
	
	char* addr;
	// addr is the path of the file of second input
	addr = argv[2];
	
	// check the length of the input
	if(argc != 3 ) {
		perror("Error: ");
		exit(EXIT_FAILURE);	
	}
    struct sockaddr_in servaddr; 

    bzero(&servaddr, sizeof(servaddr));

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htons(INADDR_ANY);
    servaddr.sin_port = htons(atoi(argv[1]));
	
	listenfd = socket(AF_INET, SOCK_STREAM, 0);
	
	// if socket is wrong, then the program will stopped with error message
	if(listenfd == -1) {
		perror("Error: ");
		exit(EXIT_FAILURE);	
	}
	
	// if bind is wrong, then the program will stopped with error message
    if(bind(listenfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) == -1) {
		perror("Error: ");
		exit(EXIT_FAILURE);	
	}
 	
	// if listen is wrong, then the program will stopped with error message
    if(listen(listenfd, 3) == -1) {
		perror("Error: ");
		exit(EXIT_FAILURE);
	}
	
	// Accpet and process incoming request
    newsockid = accept(listenfd, (struct sockaddr*) NULL, NULL);
	perform_http(newsockid, addr);
	close(newsockid);
	
}

/*---------------------------------------------------------------------------*
 *
 * cleans up opened sockets when killed by a signal.
 *
 *---------------------------------------------------------------------------*/

void cleanExit() {
    exit(0);
}

/*---------------------------------------------------------------------------*
 *
 * Accepts a request from "sockid" and sends a response to "sockid".
 *
 *---------------------------------------------------------------------------*/

perform_http(int comm_fd, char* path) {

	FILE *fp;	
	char addr[MAX_STR_LEN];
	char response [MAX_STR_LEN];
	char *p,*token, *d;
	char str[MAX_STR_LEN] = "";
	char *buffer = malloc(MAX_STR_LEN);
	char *content;
	char *realhost;
	char *firstmatch;
	char hostname[MAX_STR_LEN];

	bzero(addr, MAX_STR_LEN);

	read(comm_fd, addr, MAX_STR_LEN);	
	
	// Get the file name
	sscanf(addr, "GET http://%*[^/]/%s", str);
	
	if (str == NULL) {
		strcpy(response, "HTTP/1.0 501 Not Implemented\n");
	} else {
		if((fp = fopen(str, "r")) == NULL) {
			strcpy(response, "HTTP/1.0 404 Not Found.\n");
		} else {
			fseek(fp, 0, SEEK_END);
			long contentlen = ftell(fp);
			fseek(fp, 0, SEEK_SET);
			fread(buffer, 1, contentlen + 1, fp);
			
			//if the file can be found, then the response will be 200 identifier
			strcpy(response, "HTTP/1.0 200 OK.\n");
		}

		// Close the current file pointer for reuse
		close (fp);
		
	}
	
	// Get the system time
	time_t rawtime;
  	struct tm *info;
  	time(&rawtime);
  	info = localtime (&rawtime);
	char *part = ("%s", asctime (info));

	// Remove the new line token inorder to get the same line
	part[strlen(part) - 1] = '\0';
	strcat(response, "Date: " );
	strcat(response, part);
	strcat(response, " GMT\n");
	strcat(response, "Server: ");
	
	// Get the address of the incoming
	if(strncasecmp(addr, "GET HTTP://", 11) != 0) {
		hostname[0] = '\0';
		exit(0);
	}
	realhost = addr + 11;
	firstmatch = strpbrk(realhost, " :/\r\n\0");

	strncpy(hostname, realhost, (firstmatch - realhost));
	hostname[firstmatch - realhost] = '\0';
	strcat(response, hostname);
	strcat(response, "\r\n\r\n");
	strcat(response, buffer);
	
	// Release the memory of "buffer"
	free (buffer);

	write(comm_fd, response, sizeof(response));
}
