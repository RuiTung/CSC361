#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


/*------------------------------
* client.c
* Description: HTTP client program
* CSC 361
* Instructor: Kui Wu
-------------------------------*/

/* define maximal string and reply length, this is just an example.*/
/* MAX_RES_LEN should be defined larger (e.g. 4096) in real testing. */
#define MAX_STR_LEN 4096
#define MAX_RES_LEN 4096

/* --------- Main() routine ------------
 * three main task will be excuted:
 * accept the input URI and parse it into fragments for further operation
 * open socket connection with specified sockid ID
 * use the socket id to connect sopecified server
 * don't forget to handle errors
 */

main(int argc, char **argv) {
    char uri[MAX_STR_LEN];
    char hostname[MAX_STR_LEN];
    char identifier[MAX_STR_LEN];
    int sockid, port;
	
	// Copy the first input to the uri
	strcpy(uri, argv[1]);

	parse_URI(uri, hostname, &port, identifier);
    sockid = open_connection(hostname, port);
    perform_http(sockid, identifier, hostname, uri);
}
/*------ Parse an "uri" into "hostname" and resource "identifier" --------*/
parse_URI(char *uri, char *hostname, int *port, char *identifier) {
	char *realhost;
	char *firstmatch;
	char *path;
	
	// Check the input http address
	if(strncasecmp(uri, "HTTPS://", 8) == 0){
		printf("Error: Wrong input website\n");
		exit(EXIT_FAILURE);
	}
	
	if(strncasecmp(uri, "HTTP://", 7) != 0) {
		hostname[0] = '\0';
		exit(0);
	}
	realhost = uri + 7;
	firstmatch = strpbrk(realhost, " :/\r\n\0");
	strncpy(hostname, realhost, (firstmatch - realhost));
	hostname[firstmatch - realhost] = '\0';
	
	// Get the port number according to ":" token
	if(*firstmatch == ':') {
		*port = atoi(firstmatch+1);
	} else {
		*port = 80;	
	}
	
	// Get the path from address
	path = strchr(realhost, '/');
	if(path == NULL) {
		path[0] = '0';
	} else {
		path++;
		strcpy(identifier, path);
	}

}

/*------------------------------------*
* connect to a HTTP server using hostname and port,
* and get the resource specified by identifier
*--------------------------------------*/
perform_http(int sockid, char *identifier, char *hostname, char *uri) {
  /* connect to server and retrieve response */

	printf("\n---Request begin---\n");
	char buffer[4096];
	strcpy(buffer, "GET ");
	strcat(buffer, uri);
	strcat(buffer, " HTTP/1.0\r\n");
 	printf("%s", buffer);
	printf("Host: %s", hostname);
	printf("\nConnection: Keep-Alive\n");
	strcat(buffer, "Host: ");
	strcat(buffer, hostname);
	strcat(buffer, "\r\n");
	strcat(buffer, "Connection: Keep-Alive\r\n\r\n");
	printf("\n---Request end---\nHTTP request sent, awaiting response...\n");
	
	write(sockid, buffer, strlen(buffer) + 1);

	char header[MAX_RES_LEN];
	char receive[MAX_RES_LEN];
	
	bzero(receive, MAX_RES_LEN);
	
	// Check whether read function can read data from the server side
    if(read(sockid, receive, MAX_RES_LEN) == -1) {
		perror("Error: ");
		exit(EXIT_FAILURE);
	}
	
	// Split the content from header to body
	char* bodycontent = strstr(receive, "\r\n\r\n");
	int headerscope = strlen(receive)- strlen(bodycontent);
	
	printf("\n---Response header ---\n%.*s\n", headerscope, receive);
	printf("\n--- Response body ---%s\n", bodycontent);

	close(sockid);
}

/*---------------------------------------------------------------------------*
 *
 * open_conn() routine. It connects to a remote server on a specified port.
 *
 *---------------------------------------------------------------------------*/

int open_connection(char *hostname, int port) {
    /* generate socket
    * connect socket to the host address
    */
	int sockfd;
    char sendline[MAX_STR_LEN];
    char recvline[MAX_RES_LEN];
    struct sockaddr_in servaddr;
	struct hostent *ipaddr;
	
    sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd == -1) {
		perror("Error: ");
		exit(EXIT_FAILURE);
	}
    bzero(&servaddr,sizeof servaddr);
    servaddr.sin_family=AF_INET;
    servaddr.sin_port=htons(port);
	
	// Transfer the num-string into num
	if(inet_pton(AF_INET, hostname, &(servaddr.sin_addr)) == 0){
 		ipaddr = gethostbyname(hostname);
		memcpy(&servaddr.sin_addr, ipaddr->h_addr, ipaddr->h_length);
	}
 	
	// Check whether connection is succesful
    if((connect(sockfd,(struct sockaddr *)&servaddr, sizeof(servaddr)) == -1)) {
		perror("Error: ");
		exit(EXIT_FAILURE);
	}
	return sockfd;
}
